DROP INDEX IF EXISTS local_node_onlyone;
