#!/bin/bash

HERE=$(cd -P -- $(dirname -- "$0") && pwd -P)

INNER_POSTGRESQL_LOG_DIR="${CW_INSTALL_LOGS_DIR}"

cd ${INNER_POSTGRESQL_LOG_DIR}/wal && ls | head -n -1024 | xargs rm -rf

find ${INNER_POSTGRESQL_LOG_DIR} -type f -name "*\.log"  -o -name "*\.csv" -mtime +30 | xargs rm -f
