#!/bin/bash
export PATH=${CW_INSTALL_APP_DIR}/postgreSql/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin
export LD_LIBRARY_PATH="${CW_INSTALL_APP_DIR}/postgreSql/lib"
dbname="cloudwise_synthetic"
username="synthetic_user"
${CW_INSTALL_APP_DIR}/postgreSql/bin/psql $dbname $username -h ${CW_INSTALL_LOCAL_IP} -p${CW_POSTGRESQL_PORT} << EOF
select archive_jobqueue()
EOF
>> ${CW_INSTALL_APP_DIR}/scripts/cron/archive_jobqueue.log