#!/bin/bash

CURRENT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
THIS_SCRIPT="${CURRENT_DIR}/$(basename $0)"

CW_INSTALL_APP_DIR=$1
CW_INSTALL_DATA_DIR=$2
CW_INSTALL_LOG_DIR=$3
CW_RUN_USER=$4
port=$5
product=$6
hostIP=$7

test -f ${CW_INSTALL_APP_DIR}/bash_profile && . ${CW_INSTALL_APP_DIR}/bash_profile

# export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${CW_INSTALL_APP_DIR}/postgreSql/lib

function postgreSqlInit() {
    # 1. 修改数据目录权限
    chmod -R 700 ${CW_INSTALL_DATA_DIR}/postgreSql
    # 2. 初始化数据库
    if [ $UID -eq 0 ]; then
        su - $CW_RUN_USER -c "${CW_INSTALL_APP_DIR}/postgreSql/bin/initdb -D ${CW_INSTALL_DATA_DIR}/postgreSql --encoding=UTF8 --lc-collate=en_US.UTF-8 --lc-ctype=en_US.UTF-8"
    else
        ${CW_INSTALL_APP_DIR}/postgreSql/bin/initdb -D ${CW_INSTALL_DATA_DIR}/postgreSql --encoding=UTF8 --lc-collate=en_US.UTF-8 --lc-ctype=en_US.UTF-8
    fi
    # 覆盖配置文件postgresql.conf & 追加新配置到pg_hba.conf
    cp ${CW_INSTALL_APP_DIR}/postgreSql/postgresql.conf ${CW_INSTALL_DATA_DIR}/postgreSql/
    echo "host    all             all             0.0.0.0/0               trust" >> ${CW_INSTALL_DATA_DIR}/postgreSql/pg_hba.conf

    # 启动数据库
    result=$(bash ${CW_INSTALL_APP_DIR}/postgreSql/scripts/postgreSql start)
    echo $result
    if [[ $result =~ "[running]" ]]; then
        sleep 2
    else
        sleep 2
        bash ${CW_INSTALL_APP_DIR}/postgreSql/scripts/postgreSql start
    fi
    sleep 60
    # 初始化数据库用户

    ## 默认用户
    ${CW_INSTALL_APP_DIR}/postgreSql/bin/createuser -U $CW_RUN_USER -h${hostIP} -p${port} -s postgres
    ## 自动化CT使用的用户
    ${CW_INSTALL_APP_DIR}/postgreSql/bin/createuser -U $CW_RUN_USER -h${hostIP} -p${port} -s qauser
    ## 产品连接数据库的用户
    ${CW_INSTALL_APP_DIR}/postgreSql/bin/psql -d postgres -U $CW_RUN_USER -h${hostIP} -p${port} -c "create user synthetic_user with superuser password 'A0gqdr7c(Lfsuid';"
    
    # JKB 添加crontab
    if [ $(echo ${product}| grep -w 'jkb') ]; then
        test -d ${CW_INSTALL_APP_DIR}/scripts/cron  || mkdir -p ${CW_INSTALL_APP_DIR}/scripts/cron
        cp -arf ${CW_INSTALL_APP_DIR}/postgreSql/scripts/bash/cron/*.sh  ${CW_INSTALL_APP_DIR}/scripts/cron/
        crontab -l > job.txt
        grep -q "archive-jobqueue.sh" job.txt
        if [ $? -ne 0 ]; then
            echo "*/5 * * * * /bin/bash ${CW_INSTALL_APP_DIR}/scripts/cron/createTaskSchedule.sh  >> /tmp/createTaskSchedule.txt" >>job.txt
            echo "* */12 * * * /bin/bash ${CW_INSTALL_APP_DIR}/scripts/cron/archive-jobqueue.sh" >>job.txt
            crontab job.txt
            rm -rf job.txt
        fi
    fi
    # APM 创建告警服务使用的数据库
    if [ $(echo ${product}| grep -w 'apm') ]; then

        ${CW_INSTALL_APP_DIR}/postgreSql/bin/psql -U postgres -h${hostIP} -p${port} -c "create database cw_apm_alert;"
        ${CW_INSTALL_APP_DIR}/postgreSql/bin/psql -U postgres -h${hostIP} -p${port} -c "create database db_toushibao_main;"
    fi
}
postgreSqlInit
