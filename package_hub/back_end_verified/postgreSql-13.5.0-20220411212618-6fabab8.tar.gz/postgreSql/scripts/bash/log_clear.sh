#!/bin/bash

INNER_LOG_DIR=$1

find ${INNER_LOG_DIR} -type f -name "*\.log"  -o -name "*\.csv" -mtime +30 | xargs rm -f
