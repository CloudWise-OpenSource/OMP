#!/usr/bin/env python
# -*- coding:utf8 -*-
# Author: jerry.zhang
# Create Date: 2021-11-22 17:54:00
# Last Modified: 2021-11-22 17:54:00
# Description: 初始化 postgreSql 环境

from Core import Core
import os

SERVICE_NAME = "postgreSql"


class InitPostgreSql(Core):
    def __init__(self):
        """
        初始化json数据 及 基础方法
        """
        Core.__init__(self)
        self.SERVICE_NAME = SERVICE_NAME
        self.para = self.parameters()  # 脚本接收到的参数
        self.format_para(self.para)  # 解析脚本接收到的参数， 并初始化参数

    def run(self):
        """
        安装执行过程
        """

        CW_INSTALL_APP_DIR = os.path.dirname(self.install_args.get('base_dir'))
        CW_INSTALL_DATA_DIR = os.path.dirname(self.install_args.get('data_dir'))
        CW_INSTALL_LOGS_DIR = os.path.dirname(self.install_args.get("log_dir"))
        user = self.install_args.get('run_user')
        port = str(self.port.get('service_port'))
        init_dir = os.path.join(self.install_args.get('base_dir'), "scripts", "bash", "init.sh")
        self.sys_cmd("chmod +x {0}".format(init_dir))

        # 初始化监控宝所用的pg库
        INSTALL_PRODUCT = self.get_config_product_value_str()

        self.sys_cmd(
            "{7} {0} {1} {2} {3} {4} {5} {6}".format(
                CW_INSTALL_APP_DIR, CW_INSTALL_DATA_DIR, CW_INSTALL_LOGS_DIR, user, port,
                INSTALL_PRODUCT, self.local_ip, init_dir))


if __name__ == '__main__':
    _ = InitPostgreSql()
    _.run()
