#!/usr/bin/env python
# -*- coding:utf8 -*-
# Author: jerry.zhang
# Create Date: 2021-11-22 17:54:00
# Last Modified: 2021-11-22 17:54:00
# Description: 安装 postgreSql 环境

from Core import Core
import shutil
import os
import re

SERVICE_NAME = "postgreSql"


class InstallPostgreSql(Core):
    def __init__(self):
        """
        初始化json数据 及 基础方法
        """
        Core.__init__(self)
        self.SERVICE_NAME = SERVICE_NAME
        self.para = self.parameters()  # 脚本接收到的参数
        self.format_para(self.para)  # 解析脚本接收到的参数， 并初始化参数

    def run(self):
        """
        安装执行过程
        """
        self.out('\n *** postgreSql安装进度 *** \n')
        # 服务部署路径
        CW_INSTALL_APP_DIR = os.path.dirname(self.install_args.get("base_dir"))
        CW_INSTALL_DATA_DIR = os.path.dirname(self.install_args.get("data_dir"))
        CW_INSTALL_LOGS_DIR = os.path.dirname(self.install_args.get("log_dir"))

        # 服务相关路径
        app_path = os.path.join(CW_INSTALL_APP_DIR, SERVICE_NAME)
        conf_path = os.path.join(app_path, 'postgresql.conf')
        data_path = os.path.join(CW_INSTALL_DATA_DIR, SERVICE_NAME)
        logs_path = os.path.join(CW_INSTALL_LOGS_DIR, SERVICE_NAME)
        LOCAL_IP = self.local_ip

        # 创建通用目录
        self.check_dir()

        # postgresql.conf
        CW_RUN_USER = self.install_args.get('run_user')
        CW_POSTGRESQL_PORT = str(self.port.get("service_port"))

        # script
        script_file = os.path.join(app_path, "scripts", "postgreSql")
        createTaskSchedule_cron_file = os.path.join(app_path, "scripts/bash/cron/createTaskSchedule.sh")
        jobqueue_cron_file = os.path.join(app_path, "scripts/bash/cron/archive-jobqueue.sh")
        placeholder = {
            "CW_POSTGRESQL_PORT": CW_POSTGRESQL_PORT,
            "CW_INSTALL_APP_DIR": CW_INSTALL_APP_DIR,
            "CW_INSTALL_DATA_DIR": CW_INSTALL_DATA_DIR,
            "CW_INSTALL_LOGS_DIR": CW_INSTALL_LOGS_DIR,
            "CW_RUN_USER": CW_RUN_USER}

        self.replace(conf_path, placeholder)
        self.replace(script_file, placeholder)

        # JKB-Crontab -> JKB 产品专用
        createTaskSchedule_cron_file = os.path.join(app_path, "scripts/bash/cron/createTaskSchedule.sh")
        jobqueue_cron_file = os.path.join(app_path, "scripts/bash/cron/archive-jobqueue.sh")
        placeholder_jkb_cron = {
            "CW_POSTGRESQL_PORT": CW_POSTGRESQL_PORT,
            "CW_INSTALL_APP_DIR": CW_INSTALL_APP_DIR,
            "CW_INSTALL_DATA_DIR": CW_INSTALL_DATA_DIR,
            "CW_INSTALL_LOGS_DIR": CW_INSTALL_LOGS_DIR,
            "CW_INSTALL_LOCAL_IP": LOCAL_IP,
            "CW_RUN_USER": CW_RUN_USER}
            
        self.replace(jobqueue_cron_file, placeholder_jkb_cron)
        self.replace(createTaskSchedule_cron_file, placeholder_jkb_cron)

        # wal_log
        wal_log_src_file = os.path.join(
            app_path, "scripts", "bash", "postgresql_clear_wal_log.sh")
        wal_log_destination_file = os.path.join(
            app_path, "scripts", "postgresql_clear_wal_log.sh")

        shutil.copy(wal_log_src_file, wal_log_destination_file)

        self.replace(wal_log_destination_file, placeholder)

        JOB = '0 0 * * * /bin/bash {}/postgreSql/scripts/postgresql_clear_wal_log.sh\n'.format(CW_INSTALL_APP_DIR)
        job_tmp = os.path.join(CW_INSTALL_LOGS_DIR, "job.txt")
        _ = self.sys_cmd(
            'crontab -l >{} 2>/dev/null;echo 1>/dev/null'.format(job_tmp))
        with open(job_tmp, 'r') as f:
            res = re.findall('postgresql_clear_wal_log', f.read())
        if not res:
            with open(job_tmp, 'a') as f:
                f.write(JOB)
            _ = self.sys_cmd('crontab {}'.format(job_tmp))
            os.remove(job_tmp)

        # ~/.bashrc
        data_rc = "\nexport PATH={0}/postgreSql/bin:$PATH\n".format(CW_INSTALL_APP_DIR)
        bashrc_path = os.path.join(os.path.expanduser('~'), '.bashrc')
        self.append_file(bashrc_path, data_rc)
        self.sys_cmd('. {0}'.format(bashrc_path))
        # 创建脚本启动软链接
        self.check_dir()
        self.create_user_and_change_owner()


if __name__ == '__main__':
    _ = InstallPostgreSql()
    _.run()
