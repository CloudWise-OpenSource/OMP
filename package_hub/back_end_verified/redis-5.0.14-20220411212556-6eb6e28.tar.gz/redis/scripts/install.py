#!/usr/bin/env python
# -*- coding:utf8 -*-
# Author: jerry.zhang
# Create Date: 2021-11-22 10:35:00
# Last Modified: 2021-11-22 10:35:00
# Description: 安装 redis 环境

from Core import Core
import sys
import os
import shutil

SERVICE_NAME = "redis"


class InstallRedis(Core):
    def __init__(self):
        """
        初始化json数据 及 基础方法
        """
        Core.__init__(self)
        self.SERVICE_NAME = SERVICE_NAME
        self.para = self.parameters()  # 脚本接收到的参数
        self.format_para(self.para)  # 解析脚本接收到的参数， 并初始化参数

    def _get_basic_service_role_ip_list(self, service_name, role_type):
        """
            调用
            self._get_basic_service_role_config(self, 'hadoop', 'role'):
        """
        service_ip_list = []
        role_list = self.pub_para(["ip", "role"], service_name)
        if not isinstance(role_list, list):
            role_list = [role_list]
        for role in role_list:
            if role_type in role[1].split(","):
                service_ip_list.append(role[0])
        return service_ip_list

    def _get_basic_service_role_ip_port_list(self, role_type, port_name, service_name=SERVICE_NAME):
        """
            调用
            'hadoop', ip, 'namenode', 'namenode_rpc_port'
            self._get_basic_service_role_config(self, 'hadoop', 'role', key):
        """
        port = self.pub_para_port(port_name, service_name)
        service_ip_list = self._get_basic_service_role_ip_list(service_name, role_type)
        result = []
        for ip in service_ip_list:
            result.append("{0}:{1}".format(ip, port))

        return ",".join(result)

    def run(self):
        """
        安装执行过程
        """
        self.out('\n *** REDIS安装进度 *** \n')

        ###### 解析占位符 替换 ######
        # 服务部署路径
        CW_INSTALL_APP_DIR = os.path.dirname(self.install_args.get("base_dir"))
        CW_INSTALL_LOGS_DIR = os.path.dirname(self.install_args.get("log_dir"))
        CW_INSTALL_DATA_DIR = os.path.dirname(self.install_args.get("data_dir"))
        # 服务相关路径
        app_path = os.path.join(CW_INSTALL_APP_DIR, SERVICE_NAME)
        ## redis
        # TODO 查看是否在一台机器
        redis_list = self.pub_ip_port_str("redis", "service_port").split(",")
        CLUSTER_MODE = "alone" if len(redis_list) == 1 else "cluster"
        conf_path = os.path.join(app_path, "redis.conf")
        logs_path = os.path.join(CW_INSTALL_LOGS_DIR, "redis")
        scripts_path = os.path.join(app_path, 'scripts/{0}'.format(SERVICE_NAME))
        data_path = os.path.join(CW_INSTALL_DATA_DIR, SERVICE_NAME)
        # 创建相关文件夹
        self.check_dir()
        # 添加执行权限，创建软连接
        self.sys_cmd('chmod +x {}'.format(scripts_path))

        ## sentinel
        sentinel_conf_path = os.path.join(app_path, "sentinel.conf")
        sentinel_scripts_path = os.path.join(app_path, 'scripts/{0}'.format("redis-sentinel"))
        sentinel_logs_path = os.path.join(CW_INSTALL_LOGS_DIR, "redis", 'sentinel')
        sentinel_data_path = os.path.join(CW_INSTALL_DATA_DIR, SERVICE_NAME, 'sentinel')

        ## 创建sentinel子目录，对应的redis 的相关服务目录是父目录，也会自动创建，所以不需要重复创建redis 的 相关目录
        self.sys_cmd("mkdir -p {}".format(sentinel_logs_path))
        self.sys_cmd("mkdir -p {}".format(sentinel_data_path))

        # sentinel添加执行权限，创建软连接
        self.sys_cmd('chmod +x {}'.format(sentinel_scripts_path))

        # 添加哨兵日志目录的软链
        sentinel_log_path_link = os.path.join(CW_INSTALL_LOGS_DIR, "sentinel")
        if (CLUSTER_MODE != "alone"
                and not os.path.exists(sentinel_log_path_link)):
            shutil.os.symlink(sentinel_logs_path, sentinel_log_path_link)

        # redis.conf占位符替换
        CW_REDIS_PASSWORD = self.install_args.get('password')
        CW_SENTINEL_PASSWORD = self.install_args.get('password')
        CW_REDIS_PORT = self.port.get('service_port')

        CW_REDIS_SENTINEL_PORT = self.port.get('sentinel_port')
        CW_REDIS_MASTER_HOST = self._get_basic_service_role_ip_list(SERVICE_NAME, 'master')
        if CW_REDIS_MASTER_HOST:
            CW_REDIS_MASTER_HOST = CW_REDIS_MASTER_HOST[0]
        CW_REDIS_MASTER_SERVER = self._get_basic_service_role_ip_port_list('master', 'service_port')

        CW_REDIS_SENTINEL_SERVER = self._get_basic_service_role_ip_port_list('master',
                                                                             'sentinel_port')

        CW_REDIS_SENTINEL_HOST = ""
        if CW_REDIS_SENTINEL_SERVER:
            CW_REDIS_SENTINEL_HOST = CW_REDIS_SENTINEL_SERVER[0].split(':')[0]

        placeholder_list_conf = {
            "CW_REDIS_PORT": CW_REDIS_PORT,
            "CW_REDIS_SENTINEL_PORT": CW_REDIS_SENTINEL_PORT,
            "CW_INSTALL_APP_DIR": CW_INSTALL_APP_DIR,
            "CW_INSTALL_LOGS_DIR": CW_INSTALL_LOGS_DIR,
            "CW_INSTALL_DATA_DIR": CW_INSTALL_DATA_DIR,
            "CW_REDIS_MASTER_HOST": CW_REDIS_MASTER_HOST,
            "CW_REDIS_PASSWORD": CW_REDIS_PASSWORD,
            "CW_SENTINEL_PASSWORD": CW_SENTINEL_PASSWORD}

        self.replace(conf_path, placeholder_list_conf)
        self.replace(sentinel_conf_path, placeholder_list_conf)

        # script
        CW_RUN_USER = self.install_args.get('run_user')
        CW_LOCAL_IP = self.local_ip
        placeholder_list_script = {
            "CW_INSTALL_APP_DIR": CW_INSTALL_APP_DIR,
            "CW_RUN_USER": CW_RUN_USER,
            "CW_LOCAL_IP": CW_LOCAL_IP,
            "CW_SERVICE_PORT": CW_REDIS_PORT,
            "CW_INSTALL_APP_DIR": CW_INSTALL_APP_DIR,
            "CW_INSTALL_DATA_DIR": CW_INSTALL_DATA_DIR,
            "CW_INSTALL_LOGS_DIR": CW_INSTALL_LOGS_DIR,
            "CW_REDIS_SENTINEL_PORT": CW_REDIS_SENTINEL_PORT,
            "CW_CLUSTER_MODE": CLUSTER_MODE
        }

        self.replace(scripts_path, placeholder_list_script)
        self.replace(sentinel_scripts_path, placeholder_list_script)

        # 从节点设置指定主节点replicaof 10.0.3.210 18128  masterauth "yunzhihui123"
        if CLUSTER_MODE != 'alone':
            self.append_file(conf_path, '\nmasterauth "{0}"\n'.format(CW_REDIS_PASSWORD))
        if self.roles == 'slave':
            self.append_file(conf_path, '\nreplicaof {0} {1}\n'.format(CW_REDIS_MASTER_HOST, CW_REDIS_PORT))

        # 判断操作用户，修改目录属主。
        if self.is_root():
            self.create_user_and_change_owner()


if __name__ == '__main__':
    _ = InstallRedis()
    _.run()
