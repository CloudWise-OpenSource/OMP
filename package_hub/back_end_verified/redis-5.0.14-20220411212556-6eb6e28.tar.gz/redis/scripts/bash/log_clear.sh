#!/bin/bash

# 日志最大大小，默认1024mb
MAX_SIZE=1024
# 保留最新备份的数量
BAK_NUM=3
# 要分割的日志文件，如果有多个，用逗号分割
LOG_NAME=redis.log,redis_sentinel.log

# 备份日期标签
DATE=$(date +%F -d "today")

INNER_LOG_DIR=$1

# 根据LOG_NAME生成查找日志路径命令
array=(${LOG_NAME//,/ })
array_num=${#array[@]}
find_logs_cmd="find $INNER_LOG_DIR -type f -name ${array[0]}"
if [ $array_num -gt 1 ]; then
  for ((i = 1; i <= $array_num - 1; i++)); do
    find_logs_cmd="$find_logs_cmd -o -name ${array[i]}"
  done
fi

maxsize_byte=$((1024 * 1024 * $MAX_SIZE))

HERE=$(cd -P -- $(dirname -- "$0") && pwd -P)
®
LOGS=$($find_logs_cmd)
for log in $LOGS; do
  DIR=$(dirname $log)
  LOG=$(basename $log)
  cd $DIR
  filesize=$(ls -l $LOG | awk '{ print $5 }')
  if [ $filesize -gt $maxsize_byte ]; then
    cp $LOG $DATE.$LOG && echo '' >$LOG
  fi

  # 删除固定数量BAK_NUM备份文件中最旧的一个
  bakFileNum=$(ls -l *.$LOG | grep ^- | wc -l)
  if [ $bakFileNum -gt $BAK_NUM ]; then
    ls -rt *.$LOG | head -1 | xargs rm -f
  fi

done
