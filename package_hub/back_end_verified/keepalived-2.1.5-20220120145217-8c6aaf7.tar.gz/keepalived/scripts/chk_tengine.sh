#!/bin/bash

< /dev/tcp/${CW_MASTER_IP}/${CW_TENGINE_PORT} 
if [ $? -ne 0 ];then
    sudo /bin/bash ${CW_INSTALL_APP_DIR}/keepalived/scripts/keepalived stop 
	exit 2
else
	exit 0
fi
