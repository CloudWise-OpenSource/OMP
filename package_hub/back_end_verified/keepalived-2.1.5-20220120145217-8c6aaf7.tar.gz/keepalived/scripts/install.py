#!/usr/bin/env python
# -*- coding:utf8 -*-
# Author: jerry.zhang
# Create Date: 2021-11-24 18:03:00
# Last Modified: 2021-11-24 17:03:00
# Description: 安装 keepalived 环境
import sys

from Core import Core
import os

SERVICE_NAME = "keepalived"


class InstallKeepalived(Core):
    def __init__(self):
        """
        初始化json数据 及 基础方法
        #后面需要整改成被依赖
        """
        Core.__init__(self)
        self.SERVICE_NAME = SERVICE_NAME
        self.para = self.parameters()  # 脚本接收到的参数
        self.format_para(self.para)  # 解析脚本接收到的参数， 并初始化参数
        # self.CW_RUN_USER = self.install_args.get("run_user")
        self.CW_INSTALL_APP_DIR = os.path.dirname(self.install_args.get("base_dir"))
        self.CW_INSTALL_LOGS_DIR = os.path.dirname(self.install_args.get("log_dir"))
        # 服务相关路径
        self.app_path = os.path.join(self.CW_INSTALL_APP_DIR, SERVICE_NAME)
        self.scripts_path = os.path.join(self.app_path,
                                    'scripts/{0}'.format(SERVICE_NAME))

    def used_for_mysql(self, used_for_lst):
        conf_path = os.path.join(
            self.app_path, 'etc/keepalived/keepalived.mysql.conf')
        check_scripts_path = os.path.join(self.app_path, 'scripts/chk_mysql.sh')
        # 添加执行权限，创建软连接
        self.sys_cmd("chmod +x {}".format(self.scripts_path))
        self.sys_cmd("chmod +x {}".format(check_scripts_path))
        # 获取当前节点数据库的端口
        CW_MYSQL_PORT = self.pub_para_port('service_port', 'mysql')
        mysql_master_ip, mysql_slave_ip = [el["ip"] for el in used_for_lst]
        if mysql_master_ip == self.local_ip:
            CW_MASTER_IP = mysql_master_ip
            CW_SLAVE_IP = mysql_slave_ip
            CW_PRIOR_NUM = 100
        else:
            CW_MASTER_IP = mysql_slave_ip
            CW_SLAVE_IP = mysql_master_ip
            CW_PRIOR_NUM = 95

        # 获取当前机器网卡名称
        CW_NETWORK_CARD = self.sys_cmd("ip addr|grep {}".format(self.local_ip)).strip().split(' ')[-1]

        # 获取掩码
        netmask = self.sys_cmd("ip addr|grep {}".format(self.local_ip)).strip().split(' ')[1].split('/')[1]

        # 获取VIP_IP
        CW_VIP_IP = ""
        for item in self.data_json:
            if item.get("name") == SERVICE_NAME and item.get("ip") == self.local_ip:
                CW_VIP_IP = item.get("vip") + "/" + netmask

        # set start scripts
        place_holder_scripts = {
            "CW_INSTALL_APP_DIR": self.CW_INSTALL_APP_DIR,
            "CW_INSTALL_LOGS_DIR": self.CW_INSTALL_LOGS_DIR,
            "CW_USED_FOR_SERVICE": "mysql"
        }

        self.replace(self.scripts_path, place_holder_scripts)
        CW_RUN_USER = self.sys_cmd("whoami").strip()
        if CW_RUN_USER != "root" and \
                self.sys_cmd("sudo -n echo 'success'").strip() != "success":
            print("当前用户{}非root且不具备sudo免密条件，无法安装".format(CW_RUN_USER))
            sys.exit(1)
        # set start conf
        place_holder_conf = {
            "CW_INSTALL_APP_DIR": self.CW_INSTALL_APP_DIR,
            "CW_INSTALL_LOGS_DIR": self.CW_INSTALL_LOGS_DIR,
            "CW_RUN_USER": CW_RUN_USER,
            "CW_MYSQL_PORT": CW_MYSQL_PORT,
            "CW_NETWORK_CARD": CW_NETWORK_CARD,
            "CW_PRIOR_NUM": CW_PRIOR_NUM,
            "CW_VIP_IP": CW_VIP_IP,
            "CW_MASTER_IP": CW_MASTER_IP,
            "CW_SLAVE_IP": CW_SLAVE_IP}

        self.replace(conf_path, place_holder_conf)

        # set chk_mysql.sh
        place_holder_chk = {
            "CW_INSTALL_APP_DIR": self.CW_INSTALL_APP_DIR,
            "CW_INSTALL_LOGS_DIR": self.CW_INSTALL_LOGS_DIR,
            "CW_MYSQL_PORT": CW_MYSQL_PORT,
            "CW_MASTER_IP": CW_MASTER_IP}

        self.replace(check_scripts_path, place_holder_chk)

    def used_for_tengine(self, used_for_lst):
        conf_path = os.path.join(
            self.app_path, 'etc/keepalived/keepalived.tengine.conf')
        check_scripts_path = os.path.join(self.app_path, 'scripts/chk_tengine.sh')
        # 添加执行权限，创建软连接
        self.sys_cmd("chmod +x {}".format(self.scripts_path))
        self.sys_cmd("chmod +x {}".format(check_scripts_path))
        # 获取当前节点数据库的端口
        # CW_TENGINE_PORT = self.pub_para_port('service_port', 'tengine')
        CW_TENGINE_PORT = ""
        tengine_master_ip, tengine_slave_ip = [el["ip"] for el in used_for_lst]
        if tengine_master_ip == self.local_ip:
            CW_MASTER_IP = tengine_master_ip
            CW_SLAVE_IP = tengine_slave_ip
            CW_PRIOR_NUM = 100
        else:
            CW_MASTER_IP = tengine_slave_ip
            CW_SLAVE_IP = tengine_master_ip
            CW_PRIOR_NUM = 95

        # 获取当前机器网卡名称
        CW_NETWORK_CARD = self.sys_cmd("ip addr|grep {}".format(self.local_ip)).strip().split(' ')[-1]

        # 获取掩码
        netmask = self.sys_cmd("ip addr|grep {}".format(self.local_ip)).strip().split(' ')[1].split('/')[1]

        # 获取VIP_IP
        CW_VIP_IP = ""
        for item in self.data_json:
            if item.get("name") == "tengine" and item.get("ip") == self.local_ip:
                CW_TENGINE_PORT = ""
                for el in item.get("ports"):
                    if el.get("key") == "service_port":
                        CW_TENGINE_PORT = el["default"]
            if item.get("name") == SERVICE_NAME and item.get("ip") == self.local_ip:
                CW_VIP_IP = item.get("vip") + "/" + netmask

        # set start scripts
        place_holder_scripts = {
            "CW_INSTALL_APP_DIR": self.CW_INSTALL_APP_DIR,
            "CW_INSTALL_LOGS_DIR": self.CW_INSTALL_LOGS_DIR,
            "CW_USED_FOR_SERVICE": "tengine"
        }

        self.replace(self.scripts_path, place_holder_scripts)
        CW_RUN_USER = self.sys_cmd("whoami").strip()
        if CW_RUN_USER != "root" and \
                self.sys_cmd("sudo -n echo 'success'").strip() != "success":
            print("当前用户{}非root且不具备sudo免密条件，无法安装".format(CW_RUN_USER))
            sys.exit(1)
        # set start conf
        place_holder_conf = {
            "CW_INSTALL_APP_DIR": self.CW_INSTALL_APP_DIR,
            "CW_INSTALL_LOGS_DIR": self.CW_INSTALL_LOGS_DIR,
            "CW_RUN_USER": CW_RUN_USER,
            "CW_TENGINE_PORT": CW_TENGINE_PORT,
            "CW_NETWORK_CARD": CW_NETWORK_CARD,
            "CW_PRIOR_NUM": CW_PRIOR_NUM,
            "CW_VIP_IP": CW_VIP_IP,
            "CW_MASTER_IP": CW_MASTER_IP,
            "CW_SLAVE_IP": CW_SLAVE_IP
        }

        self.replace(conf_path, place_holder_conf)

        # set chk_mysql.sh
        place_holder_chk = {
            "CW_INSTALL_APP_DIR": self.CW_INSTALL_APP_DIR,
            "CW_INSTALL_LOGS_DIR": self.CW_INSTALL_LOGS_DIR,
            "CW_TENGINE_PORT": CW_TENGINE_PORT,
            "CW_MASTER_IP": CW_MASTER_IP
        }

        self.replace(check_scripts_path, place_holder_chk)

    def run(self):
        # 确定keepalived的用途并确定mysql服务
        used_for = None
        for item in self.data_json:
            if item.get("name") == SERVICE_NAME and \
                    item.get("ip") == self.local_ip:
                used_for = item.get("role")
        used_for_lst = list()
        used_for_cluster = None
        for item in self.data_json:
            if item.get("name") == used_for and \
                    item.get("ip") == self.local_ip:
                used_for_cluster = item.get("cluster_name")
        for item in self.data_json:
            if item.get("name") == used_for and \
                    item.get("cluster_name") == used_for_cluster:
                used_for_lst.append(item)
        if len(used_for_lst) != 2:
            print("当前keepalived仅支持双节点服务高可用模式")
            sys.exit(1)
        # 创建通用目录
        self.check_dir()
        if hasattr(self, "used_for_{}".format(used_for)):
            getattr(self, "used_for_{}".format(used_for))(used_for_lst)
        else:
            print("无法确定此keepalived所支持的服务！")
            sys.exit(1)
        # 判断操作用户，修改目录属主。
        if self.is_root():
            self.create_user_and_change_owner()


if __name__ == "__main__":
    _ = InstallKeepalived()
    _.run()
