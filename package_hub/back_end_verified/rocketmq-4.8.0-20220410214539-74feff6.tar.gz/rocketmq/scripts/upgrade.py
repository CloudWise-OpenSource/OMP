# -*- coding:utf-8 -*-
# Project: upgrade
# Author:Times.niu@yunzhihui.com
# Create time: 2021/12/23 2:20 下午

from Core import Core, init_argparse_upgrade

SERVICE_NAME = "rocketmq"


class UpgradeManger(object):
    def __init__(self, local_ip, json_path):
        self.local_ip = local_ip
        self.core = Core(local_ip, json_path, SERVICE_NAME)
        # 服务启动用户
        self.CW_RUN_USER = self.core.get_config_common_value('CW_RUN_USER')
        self.CW_INSTALL_APP_DIR = self.core.get_config_common_value("CW_INSTALL_APP_DIR")
        self.CW_INSTALL_LOGS_DIR = self.core.get_config_common_value("CW_INSTALL_LOGS_DIR")
        self.CW_INSTALL_DATA_DIR = self.core.get_config_common_value("CW_INSTALL_DATA_DIR")
        # 服务相关路径
        self.app_path = self.core.path_join(self.CW_INSTALL_APP_DIR, SERVICE_NAME)
        self.conf_path = self.core.path_join(self.app_path, "conf")
        self.data_path = self.core.path_join(self.CW_INSTALL_DATA_DIR, SERVICE_NAME)
        self.log_path = self.core.path_join(self.CW_INSTALL_LOGS_DIR, SERVICE_NAME)
        commitlog_path = self.core.path_join(self.data_path, 'store/commitlog')
        consumequeue_path = self.core.path_join(self.data_path, 'store/consumequeue')
        index_path = self.core.path_join(self.data_path, 'store/index')

        # 创建通用目录
        self.core.make_depend_dir()
        self.core.make_dir(self.data_path)
        self.core.make_dir(self.log_path)
        self.core.make_dir(commitlog_path)
        self.core.make_dir(consumequeue_path)
        self.core.make_dir(index_path)

    def config_update(self):
        # rocketmq
        CW_JVM_HEAP_SIZE = self.core.get_config_current_basic_value("memory")
        CW_NAMESRV_PORT = self.core.get_config_current_basic_value('namesrv_port')
        CW_BROKER_PORT = self.core.get_config_current_basic_value('broker_port')

        # ACL认证的账号密码和白名单地址
        CW_ROCKETMQ_USERNAME = self.core.get_config_current_basic_value('username')
        CW_ROCKETMQ_PASSWORD = self.core.get_config_current_basic_value('password')
        CW_WHITE_ADDR = self.core.get_service_ip_port_list_str("rocketmq", "namesrv_port").replace(
            ":{}".format(CW_NAMESRV_PORT), "")

        # namesrv 集群的ip_port
        CW_NAMESRV_SERVERS = self.core.get_service_ip_port_list_str("rocketmq", "namesrv_port").replace(",", ";")

        # rocketmq支持单节点和多master、多slave的集群安装，只支持1个节点或者偶数个节点
        # 默认集群列表的前半部分为master节点、后半部分为slave节点，前半部分的第一个master节点与后半部分的第一个slave节点为一组 m-s
        rocketmq_service_list = self.core.get_service_ip_port_list_str("rocketmq", "namesrv_port").split(",")
        rocketmq_num = len(rocketmq_service_list)
        if rocketmq_num == 1:
            CW_BROKER_NAME = "broker-0"
            CW_BROKER_ID = 0
            CW_BROKER_ROLE = "ASYNC_MASTER"
        elif int(rocketmq_num) % 2 == 0:
            for i in range(0, rocketmq_num / 2, 1):
                if rocketmq_service_list[i] == "{0}:{1}".format(self.local_ip, CW_NAMESRV_PORT):
                    CW_BROKER_NAME = "broker-{}".format(i)
                    CW_BROKER_ID = 0
                    CW_BROKER_ROLE = "ASYNC_MASTER"
            for j in range(rocketmq_num / 2, rocketmq_num, 1):
                if rocketmq_service_list[j] == "{0}:{1}".format(self.local_ip, CW_NAMESRV_PORT):
                    CW_BROKER_NAME = "broker-{}".format(j - rocketmq_num / 2)
                    CW_BROKER_ID = 1
                    CW_BROKER_ROLE = "SLAVE"
        else:
            print("The number of {} nodes is unsupported".format(rocketmq_num))

        # 需要替换占位符的配置文件路径
        # runserver.sh
        runserver_sh_path = self.core.path_join(self.app_path, 'bin/runserver.sh')
        placeholder_list_runserver_sh = [
            {"CW_JVM_HEAP_SIZE": CW_JVM_HEAP_SIZE},
            {"CW_INSTALL_LOGS_DIR": self.log_path}
        ]
        self.core.replace_placeholder(runserver_sh_path, placeholder_list_runserver_sh)

        # runbroker.sh
        runbroker_sh_path = self.core.path_join(self.app_path, 'bin/runbroker.sh')
        placeholder_list_runbroker_sh = [
            {"CW_JVM_HEAP_SIZE": CW_JVM_HEAP_SIZE},
            {"CW_INSTALL_LOGS_DIR": self.log_path}
        ]
        self.core.replace_placeholder(runbroker_sh_path, placeholder_list_runbroker_sh)

        # namesrv.properties
        namesrv_conf_path = self.core.path_join(self.conf_path, 'namesrv.properties')
        placeholder_list_namesrv_conf = [
            {"CW_NAMESRV_PORT": CW_NAMESRV_PORT},
            {"CW_INSTALL_LOGS_DIR": self.log_path}
        ]
        self.core.replace_placeholder(namesrv_conf_path, placeholder_list_namesrv_conf)

        # broker.properties
        broker_conf_path = self.core.path_join(self.conf_path, 'broker.properties')
        placeholder_list_broker_conf = [
            {"CW_BROKER_NAME": CW_BROKER_NAME},
            {"CW_BROKER_ID": CW_BROKER_ID},
            {"CW_LOCAL_IP": self.local_ip},
            {"CW_NAMESRV_SERVERS": CW_NAMESRV_SERVERS},
            {"CW_BROKER_PORT": CW_BROKER_PORT},
            {"CW_INSTALL_DATA_DIR": self.data_path},
            {"CW_BROKER_ROLE": CW_BROKER_ROLE},
        ]
        self.core.replace_placeholder(broker_conf_path, placeholder_list_broker_conf)

        # logback_namesrv.xml && logback_broker.xml && logback_tools.xml
        logback_namesrv_path = self.core.path_join(self.conf_path, 'logback_namesrv.xml')
        logback_broker_path = self.core.path_join(self.conf_path, 'logback_broker.xml')
        logback_tools_path = self.core.path_join(self.conf_path, 'logback_tools.xml')
        placeholder_list_logback_conf = [
            {"CW_INSTALL_LOGS_DIR": self.log_path}
        ]
        self.core.replace_placeholder(logback_namesrv_path, placeholder_list_logback_conf)
        self.core.replace_placeholder(logback_broker_path, placeholder_list_logback_conf)
        self.core.replace_placeholder(logback_tools_path, placeholder_list_logback_conf)

        # plain_acl.yml
        acl_conf_path = self.core.path_join(self.conf_path, 'plain_acl.yml')
        placeholder_acl_conf = [
            {"CW_WHITE_ADDR": CW_WHITE_ADDR},
            {"CW_ROCKETMQ_USERNAME": CW_ROCKETMQ_USERNAME},
            {"CW_ROCKETMQ_PASSWORD": CW_ROCKETMQ_PASSWORD}
        ]
        self.core.replace_placeholder(acl_conf_path, placeholder_acl_conf)

        # scripts/rocketmq
        script_path = self.core.path_join(self.app_path, "scripts", SERVICE_NAME)
        placeholder_list_rocketmq = [
            {"CW_RUN_USER": self.CW_RUN_USER},
            {"CW_INSTALL_APP_DIR": self.CW_INSTALL_APP_DIR},
            {"CW_INSTALL_LOGS_DIR": self.CW_INSTALL_LOGS_DIR},
            {"CW_INSTALL_DATA_DIR": self.CW_INSTALL_DATA_DIR}
        ]
        self.core.replace_placeholder(script_path, placeholder_list_rocketmq)

        # 创建脚本启动软链接
        self.core.make_script_link()

        # 判断操作用户，修改目录属主。
        if self.core.is_root():
            for path in (self.app_path, self.data_path, self.log_path):
                self.core.run_shell(
                    'chown -R {user}.{user} {path}'.format(**{"user": self.CW_RUN_USER, "path": path}))

    def run(self):
        self.config_update()


if __name__ == '__main__':
    args = init_argparse_upgrade()
    UpgradeManger(args.local_ip, args.json_path).run()
