#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
from Core import Core

SERVICE_NAME = "rocketmq"


class InstallRocketmq(Core):
    def __init__(self):
        """
        初始化json数据 及 基础方法
        """
        Core.__init__(self)
        self.SERVICE_NAME = SERVICE_NAME
        self.para = self.parameters()  # 脚本接收到的参数
        self.format_para(self.para)  # 解析脚本接收到的参数， 并初始化参数

    def run(self):
        # 服务部署路径
        CW_RUN_USER = self.install_args.get('run_user')
        CW_INSTALL_APP_DIR = os.path.dirname(self.install_args.get('base_dir'))
        CW_INSTALL_LOGS_DIR = os.path.dirname(self.install_args.get('log_dir'))
        CW_INSTALL_DATA_DIR = os.path.dirname(self.install_args.get('data_dir'))

        # 服务相关路径
        app_path = os.path.join(CW_INSTALL_APP_DIR, SERVICE_NAME)
        conf_path = os.path.join(app_path, 'conf')
        data_path = os.path.join(CW_INSTALL_DATA_DIR, SERVICE_NAME)
        log_path = os.path.join(CW_INSTALL_LOGS_DIR, SERVICE_NAME)
        commitlog_path = os.path.join(data_path, 'store/commitlog')
        consumequeue_path = os.path.join(data_path, 'store/consumequeue')
        index_path = os.path.join(data_path, 'store/index')

        # 创建通用目录
        self.check_dir()
        self.sys_cmd("mkdir -p {0} && mkdir {1} && mkdir {2}".format(
            commitlog_path, consumequeue_path, index_path))

        # rocketmq
        CW_JVM_HEAP_SIZE = self.install_args.get("memory")
        CW_NAMESRV_PORT = str(self.port.get('namesrv_port'))
        CW_BROKER_PORT = str(self.port.get('broker_port'))

        # ACL认证的账号密码和白名单地址
        CW_ROCKETMQ_USERNAME = self.install_args.get('username')
        CW_ROCKETMQ_PASSWORD = self.install_args.get('password')

        # 兼容适配DOSM不使用ACL校验，使用IP白名单的形式
        # CW_WHITE_ADDR = self.pub_ip_port_str("rocketmq", "namesrv_port").replace(
        #     ":{}".format(CW_NAMESRV_PORT), "")
        # 获取所有节点IP地址
        ips_list = set()
        for service in self.data_json:
            ips_list.add(service.get("ip"))
        CW_WHITE_ADDR = ",".join(ips_list)

        # namesrv 集群的ip_port
        CW_NAMESRV_SERVERS = self.pub_ip_port_str("rocketmq", "namesrv_port").replace(",", ";")

        # rocketmq支持单节点和多master、多slave的集群安装，只支持1个节点或者偶数个节点
        # 默认集群列表的前半部分为master节点、后半部分为slave节点，前半部分的第一个master节点与后半部分的第一个slave节点为一组 m-s
        rocketmq_service_list = self.pub_ip_port_str("rocketmq", "namesrv_port").split(",")
        rocketmq_num = len(rocketmq_service_list)
        if rocketmq_num == 1:
            CW_BROKER_NAME = "broker-0"
            CW_BROKER_ID = 0
            CW_BROKER_ROLE = "ASYNC_MASTER"
        elif int(rocketmq_num) % 2 == 0:
            for i in range(0, rocketmq_num / 2, 1):
                if rocketmq_service_list[i] == "{0}:{1}".format(self.local_ip, CW_NAMESRV_PORT):
                    CW_BROKER_NAME = "broker-{}".format(i)
                    CW_BROKER_ID = 0
                    CW_BROKER_ROLE = "ASYNC_MASTER"
            for j in range(rocketmq_num / 2, rocketmq_num, 1):
                if rocketmq_service_list[j] == "{0}:{1}".format(self.local_ip, CW_NAMESRV_PORT):
                    CW_BROKER_NAME = "broker-{}".format(j - rocketmq_num / 2)
                    CW_BROKER_ID = 1
                    CW_BROKER_ROLE = "SLAVE"
        else:
            print("The number of {} nodes is unsupported".format(rocketmq_num))

        # 需要替换占位符的配置文件路径
        # runserver.sh
        runserver_sh_path = os.path.join(app_path, 'bin/runserver.sh')
        placeholder_list_runserver_sh = {
            "CW_JVM_HEAP_SIZE": CW_JVM_HEAP_SIZE,
            "CW_INSTALL_LOGS_DIR": log_path}

        self.replace(runserver_sh_path, placeholder_list_runserver_sh)

        # runbroker.sh
        runbroker_sh_path = os.path.join(app_path, 'bin/runbroker.sh')
        placeholder_list_runbroker_sh = {
            "CW_JVM_HEAP_SIZE": CW_JVM_HEAP_SIZE,
            "CW_INSTALL_LOGS_DIR": log_path}

        self.replace(runbroker_sh_path, placeholder_list_runbroker_sh)

        # namesrv.properties
        namesrv_conf_path = os.path.join(conf_path, 'namesrv.properties')
        placeholder_list_namesrv_conf = {
            "CW_NAMESRV_PORT": CW_NAMESRV_PORT,
            "CW_INSTALL_LOGS_DIR": log_path}

        self.replace(namesrv_conf_path, placeholder_list_namesrv_conf)

        # broker.properties
        broker_conf_path = os.path.join(conf_path, 'broker.properties')
        placeholder_list_broker_conf = {
            "CW_BROKER_NAME": CW_BROKER_NAME,
            "CW_BROKER_ID": str(CW_BROKER_ID),
            "CW_LOCAL_IP": self.local_ip,
            "CW_NAMESRV_SERVERS": CW_NAMESRV_SERVERS,
            "CW_BROKER_PORT": CW_BROKER_PORT,
            "CW_INSTALL_DATA_DIR": data_path,
            "CW_BROKER_ROLE": CW_BROKER_ROLE
        }

        self.replace(broker_conf_path, placeholder_list_broker_conf)

        # logback_namesrv.xml && logback_broker.xml && logback_tools.xml
        logback_namesrv_path = os.path.join(conf_path, 'logback_namesrv.xml')
        logback_broker_path = os.path.join(conf_path, 'logback_broker.xml')
        logback_tools_path = os.path.join(conf_path, 'logback_tools.xml')
        placeholder_list_logback_conf = {"CW_INSTALL_LOGS_DIR": log_path}

        self.replace(logback_namesrv_path, placeholder_list_logback_conf)
        self.replace(logback_broker_path, placeholder_list_logback_conf)
        self.replace(logback_tools_path, placeholder_list_logback_conf)

        # plain_acl.yml
        acl_conf_path = os.path.join(conf_path, 'plain_acl.yml')
        placeholder_acl_conf = {
            "CW_WHITE_ADDR": CW_WHITE_ADDR,
            "CW_ROCKETMQ_USERNAME": CW_ROCKETMQ_USERNAME,
            "CW_ROCKETMQ_PASSWORD": CW_ROCKETMQ_PASSWORD}

        self.replace(acl_conf_path, placeholder_acl_conf)

        # scripts/rocketmq
        script_path = os.path.join(app_path, "scripts", SERVICE_NAME)
        placeholder_list_rocketmq = {
            "CW_RUN_USER": CW_RUN_USER,
            "CW_INSTALL_APP_DIR": CW_INSTALL_APP_DIR,
            "CW_INSTALL_LOGS_DIR": CW_INSTALL_LOGS_DIR,
            "CW_INSTALL_DATA_DIR": CW_INSTALL_DATA_DIR}

        self.replace(script_path, placeholder_list_rocketmq)

        self.create_user_and_change_owner()
        self.declare_var()


if __name__ == '__main__':
    _ = InstallRocketmq()
    _.run()
