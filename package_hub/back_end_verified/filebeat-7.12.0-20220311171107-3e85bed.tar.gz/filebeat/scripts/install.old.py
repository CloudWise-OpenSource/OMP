#!/usr/bin/env python
# -*- coding: utf-8 -*-

from Core import Core, init_argparse

# 服务名称，按需修改
SERVICE_NAME = "filebeat"


def install(local_ip, json_path):
    core = Core(local_ip, json_path, SERVICE_NAME)

    # 解析占位符 替换
    # 服务运行用户
    CW_RUN_USER = core.get_config_common_value("CW_RUN_USER")
    # 服务部署路径
    CW_INSTALL_APP_DIR = core.get_config_common_value("CW_INSTALL_APP_DIR")
    CW_INSTALL_LOGS_DIR = core.get_config_common_value("CW_INSTALL_LOGS_DIR")
    CW_INSTALL_DATA_DIR = core.get_config_common_value("CW_INSTALL_DATA_DIR")
    
    # 服务相关路径
    app_path = core.path_join(CW_INSTALL_APP_DIR, SERVICE_NAME)
    logs_path = core.path_join(app_path, "logs")
    scripts_path = core.path_join(app_path, 'scripts/{0}'.format(SERVICE_NAME))
    # 创建相关文件夹
    core.make_depend_dir()
    core.make_dir(logs_path)

    # 添加执行权限，创建软连接
    core.run_shell('chmod +x {}'.format(scripts_path))
    core.make_script_link()

    # filebeat
    # CW_SERVICE_PORT = core.get_config_current_service_value('service_port')

    # set start script
    place_holder_script = [
        {"CW_RUN_USER": CW_RUN_USER},
        {"CW_LOCAL_IP": local_ip},
        {"CW_INSTALL_APP_DIR": CW_INSTALL_APP_DIR},
        {"CW_INSTALL_LOGS_DIR": CW_INSTALL_LOGS_DIR},
        {"CW_INSTALL_DATA_DIR": CW_INSTALL_DATA_DIR},

    ]
    core.replace_placeholder(scripts_path, place_holder_script)

    # set filebeat.yml
    temp_str = core.get_service_ip_port_list_str("kafka", "service_port")
    CW_KAFKA_HOSTS = ''
    for item in temp_str.split(','):
        ele = '"' + item + '"'
        if CW_KAFKA_HOSTS:
            CW_KAFKA_HOSTS = CW_KAFKA_HOSTS + ',' + ele
        else:
            CW_KAFKA_HOSTS = ele
    filebeat_yml_file = core.path_join(app_path, 'filebeat.yml')
    core.replace_placeholder(filebeat_yml_file, place_holder_script)
    core.replace_placeholder(filebeat_yml_file, [{"CW_KAFKA_HOSTS": CW_KAFKA_HOSTS}])


if __name__ == '__main__':
    args = init_argparse()
    install(args.local_ip, args.json_path)
