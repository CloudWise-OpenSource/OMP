#!/usr/bin/env python
# -*- coding:utf8 -*-

from Core import Core
import os

SERVICE_NAME = "filebeat"

class Installfilebeat(Core):
    def __init__(self):
        """
        初始化json数据 及 基础方法
        """
        Core.__init__(self)
        self.SERVICE_NAME = SERVICE_NAME
        self.para = self.parameters()  # 脚本接收到的参数
        self.format_para(self.para)  # 解析脚本接收到的参数， 并初始化参数

    def run(self):
        # 服务部署路径
        CW_INSTALL_APP_DIR = os.path.dirname(self.install_args.get('base_dir'))
        CW_INSTALL_DATA_DIR = os.path.dirname(self.install_args.get('data_dir'))
        CW_INSTALL_LOGS_DIR = os.path.dirname(self.install_args.get('log_dir'))
        CW_RUN_USER = self.install_args.get("run_user")

        # 服务相关路径
        app_path = os.path.join(CW_INSTALL_APP_DIR, SERVICE_NAME)
        scripts_path = os.path.join(app_path, 'scripts/{0}'.format(SERVICE_NAME))
        logs_path = os.path.join(CW_INSTALL_LOGS_DIR, SERVICE_NAME)
        filebeat_conf = os.path.join(app_path, 'filebeat.yml')

        # 创建相关文件夹和目录
        self.check_dir()
        self.create_user_and_change_owner()

        # 添加执行权限，创建软连接
        self.sys_cmd('chmod +x {}'.format(scripts_path))

        # kafka信息获取
        KAFKA_IP_PORT_TEMP = self.pub_ip_port_str('kafka', 'service_port')
        CW_KAFKA_HOSTS = ''
        for item in KAFKA_IP_PORT_TEMP.split(','):
            ele = '"' + item + '"'
            if CW_KAFKA_HOSTS:
                CW_KAFKA_HOSTS = CW_KAFKA_HOSTS + ',' + ele
            else:
                CW_KAFKA_HOSTS = ele

        # 占位符替换
        place_holder_script = {
            "CW_RUN_USER": CW_RUN_USER,
            "CW_LOCAL_IP": self.local_ip,
            "CW_INSTALL_APP_DIR": CW_INSTALL_APP_DIR,
            "CW_INSTALL_DATA_DIR": CW_INSTALL_DATA_DIR,
            "CW_INSTALL_LOGS_DIR": CW_INSTALL_LOGS_DIR,
            "CW_KAFKA_HOSTS": CW_KAFKA_HOSTS
        }

        #替换
        self.replace(scripts_path, place_holder_script)
        self.replace(filebeat_conf, place_holder_script)


        
        self.create_user_and_change_owner()

if __name__ == "__main__":
    _ = Installfilebeat()
    _.run()