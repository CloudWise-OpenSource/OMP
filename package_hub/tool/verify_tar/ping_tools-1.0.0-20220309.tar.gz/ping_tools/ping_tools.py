#!/usr/bin/env python3
# -*- coding:utf8 -*-
# Author: light.wang
# Create Date: 2021-11-18 17:02:00
# Last Modified: 2021-11-18 17:02:00
# Description: 在多台主机上批量执行ping命令快速检查，主机到主机，主机到域名之间网络是否连通
import json
import argparse
import subprocess


class PingTools:

    @classmethod
    def parameters(cls):
        """
        传递参数
        :return:
        """
        parser = argparse.ArgumentParser()
        parser.add_argument("--ip", "-ip", help="当前主机IP")
        parser.add_argument("--host", "-host", help="主机或者域名")
        _ping_tools = parser.parse_args()
        return _ping_tools

    @staticmethod
    def system_command(command):
        """
        调用linux系统命令
        :param command:
        :return:
        """
        shell = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        stdout, stderr = shell.communicate()
        try:
            return stdout.decode("utf8"), stderr.decode("utf8"), shell.returncode
        except Exception:
            return stdout.decode("gbk"), stderr.decode("gbk"), shell.returncode

    def ping(self, host_or_domain_name):
        """
        ping 执行命令
        :param host_or_domain_name:
        :return:
        """
        stdout, stderr, return_code = self.system_command(
            'ping  -c1 {} '.format(host_or_domain_name)
        )
        return stdout, stderr, return_code

    def run(self):
        """
        调用逻辑
        :return:
        """
        host_down_list = []
        host_up_list = []
        host_status = {'down': host_down_list,'up': host_up_list}
        if self.parameters().host:
            for ip in self.parameters().host.split(','):
                stdout, stderr, return_code = self.ping(ip)
                if return_code:
                    host_down_list.append(ip)
                else:
                    host_up_list.append(ip)
        print(json.dumps({'host': host_status}))
        return json.dumps({'host': host_status})


if __name__ == '__main__':
    p = PingTools()
    p.run()
    # python3 ping_tools.py --host '127.0.0.1,10.0.23.118,10.0.0.23,www.baidu.com,www.qq.com1'
