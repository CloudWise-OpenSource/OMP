#!/usr/bin/env python3
# -*- coding:utf8 -*-
# Author: light.wang
# Create Date: 2021-11-15 17:02:00
# Last Modified: 2021-11-15 17:02:00
# Description: kafka消费者工具，可快速验证数据是否可以写入kafka

import argparse
import json
import os
import subprocess

class PushTest:
    

    @classmethod
    def parameters(cls):
        """
        传递参数
        :return:
        """
        parser = argparse.ArgumentParser()
        parser.add_argument("--input", "-input", help="指定输入文件", default='test.txt')
        parser.add_argument("--push_dir", "-push_dir", help="文件存放路径", default='/data')
        parser.add_argument("--file_name", "-file_name", help="文件存放名称", default='test.txt')
        parser.add_argument("--ip", "-ip", help="指定ip", default='127.0.0.1')
        system_time = parser.parse_args()
        return system_time

    def local_cmd(self,command):
        """
        执行本地shell命令
        :param command: 执行命令
        :return: (stdout, stderr, ret_code)
        """
        p = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=True
        )
        stdout, stderr = p.communicate()
        _out, _err, _code = \
            stdout.decode("utf8"), stderr.decode("utf8"), p.returncode
        return _out, _err, _code

    def run(self):
        """
        调用逻辑
        :return:
        """
        if self.parameters().input:
            new_name = os.path.join(self.parameters().push_dir, self.parameters().file_name)
            self.local_cmd("mkdir -p {0} && mv {1} {2}".format(self.parameters().push_dir, self.parameters().input, new_name))

            


if __name__ == '__main__':
    push = PushTest()
    push.run()
    print("文件推送完成")
