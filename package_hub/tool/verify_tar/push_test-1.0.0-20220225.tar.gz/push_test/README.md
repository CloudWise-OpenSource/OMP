# 推送文件工具

## 场景描述

推送文件至对应主机路径下，可修改文件名，若指定目录不存在则创建。

## 1.依赖：
- Python环境：Python 3.6

##  2.入参

| 字段     | 要求 | 参数说明        |
| -------- | ---- | -------------------------|
| input  | 必须 | 绝对路径：/root/input_1.txt         |
| push_dir  | 必须 | 绝对路径：/data         |
| file_name | 必须 | 存放的文件名: input.txt |

## 3. 输出
[root@oracle data]# ls /data    
input.txt  

## 4.执行方式 
```bash
python3 test.py --input  /data/input_1.txt --push_dir /data  --file_name input.txt
```

