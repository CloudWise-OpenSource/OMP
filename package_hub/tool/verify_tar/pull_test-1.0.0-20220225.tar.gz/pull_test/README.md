# 拉取文件工具

## 场景描述

拉取文件或文件夹至OMP服务package_hub/tool/download_data目录下，并支持下载至本地，当拉取对象为文件夹时，会对其进行压缩打包处理。    
**为防止存储被占满，请注意拉取文件大小！**

## 1.依赖：
- Python环境：Python 3.6

##  2.入参

| 字段     | 要求 | 参数说明        |
| -------- | ---- | -------------------------|
| output  | 必须  | 输出文件名：output.tar.gz，为防止文件名重复，平台会增加随机字符串前缀         |
| pull_dir  | 必须 | 目标机器上需要拉取的文件或目录的绝对路径：/tmp        |


## 3. 输出
[root@oracle test]# ls /data/omp/package_hub/tool/download_data     
000000-output.tar.gz

## 4.执行方式 
使用omp页面点击执行
