#!/usr/bin/env python3
# -*- coding:utf8 -*-
# Author: light.wang
# Create Date: 2021-11-15 17:02:00
# Last Modified: 2021-11-15 17:02:00
# Description: 拉取文件工具

import argparse
import json
import subprocess

class PullTest:
    

    @classmethod
    def parameters(cls):
        """
        传递参数
        :return:
        """
        parser = argparse.ArgumentParser()
        parser.add_argument("--output", "-output", help="指定输入文件")
        parser.add_argument("--pull_dir", "-pull_dir", help="文件")
        parser.add_argument("--ip", "-ip", help="指定ip", default='127.0.0.1')
        system_time = parser.parse_args()
        return system_time

    def local_cmd(self,command):
        """
        执行本地shell命令
        :param command: 执行命令
        :return: (stdout, stderr, ret_code)
        """
        p = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=True
        )
        stdout, stderr = p.communicate()
        _out, _err, _code = \
            stdout.decode("utf8"), stderr.decode("utf8"), p.returncode
        return _out, _err, _code

    def run(self):
        """
        调用逻辑
        :return:
        """
        output = self.parameters().output
        if output:
            file_name = output.rsplit("/",1)
            self.local_cmd("cd {0} && tar -zcf {1} {2}".format(
                file_name[0],file_name[1], self.parameters().pull_dir
                )
            )

if __name__ == '__main__':
    kafka = PullTest()
    kafka.run()
    print("文件拉取完成")

