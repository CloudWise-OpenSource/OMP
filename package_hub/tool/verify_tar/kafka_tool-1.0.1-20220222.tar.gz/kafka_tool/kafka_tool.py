#!/usr/bin/env python3
# -*- coding:utf8 -*-
# Author: light.wang
# Create Date: 2021-11-15 17:02:00
# Last Modified: 2021-11-15 17:02:00
# Description: kafka消费者工具，可快速验证数据是否可以写入kafka

from kafka import KafkaProducer, KafkaConsumer
import argparse
import json


class KafkaTest:

    @classmethod
    def parameters(cls):
        """
        传递参数
        :return:
        """
        parser = argparse.ArgumentParser()
        parser.add_argument("--role", "-role", help="指定角色")
        parser.add_argument("--output", "-output", help="指定输出文件")
        parser.add_argument("--input", "-input", help="指定输入文件")
        parser.add_argument("--mode", "-mode", help="消费模式", default='latest')
        parser.add_argument("--topic", "-topic", help="指定topic", default='kafka_test_topic')
        parser.add_argument("--ip", "-ip", help="指定ip", default='127.0.0.1')
        parser.add_argument("--service_port", "-service_port", help="指定端口", default='9092')
        system_time = parser.parse_args()
        return system_time

    def kafka_producer(self):
        """
        kafka生产者
        :param data:
        :return:
        """
        producer = KafkaProducer(
            value_serializer=lambda v: json.dumps(v).encode('utf-8'),
            bootstrap_servers=["{0}:{1}".format(self.parameters().ip, self.parameters().service_port)]
        )
        if self.parameters().input:
            with open(self.parameters().input) as f:
                data = f.read()
        else:
            data = {'status': 'success'}
        producer.send(self.parameters().topic, data)
        producer.close()

    def kafka_consumer(self):
        """
        kafka消费者
        :return:
        """
        consumer = KafkaConsumer(self.parameters().topic, group_id="kafkaToolGroup",
                                 bootstrap_servers=[
                                     "{0}:{1}".format(self.parameters().ip, self.parameters().service_port)],
                                 consumer_timeout_ms=5000,
                                 auto_offset_reset=self.parameters().mode,
                                 value_deserializer=json.loads
                                 )

        print(consumer)
        for message in consumer:
            if self.parameters().output:
                with open(self.parameters().output, 'w+') as f:
                    f.write(message.value)
            else:
                print(message.value)

    def run(self):
        """
        调用逻辑
        :return:
        """
        if self.parameters().role == 'producer':
            self.kafka_producer()
        elif self.parameters().role == 'consumer':
            self.kafka_consumer()
        else:
            self.kafka_producer()
            self.kafka_consumer()


if __name__ == '__main__':
    kafka = KafkaTest()
    kafka.run()

"""
earliest： 当各分区下有已提交的offset时，从提交的offset开始消费；无提交的offset时，从头开始消费
latest： 当各分区下有已提交的offset时，从提交的offset开始消费；无提交的offset时，消费新产生的该分区下的数据
none： topic各分区都存在已提交的offset时，从offset后开始消费；只要有一个分区不存在已提交的offset，则抛出异常
"""
