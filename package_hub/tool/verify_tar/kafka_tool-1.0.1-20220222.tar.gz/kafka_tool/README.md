# kafka生产者/消费者工具

## 场景描述



kafka生产者/消费者工具，可快速验证数据是否可以写入kafka

- 生产者可指定Topic，生产数据，未指定使用默认topic：kafka_test_topic，生产者数据从input.txt中获取

- 消费者可指定Topic，消费数据，未指定消费默认topic：kafka_test_topic，消费者将数据消费到output.txt



## 1.依赖：

- Python环境：Python 3.6

- 三方库： kafka-python

```bash
pip3 install kafka-python
```

## 2.入参

|     字段     | 要求 |                    参数说明                    |
| :----------: | :--: | :--------------------------------------------: |
|     role     | 可选 |        生产者：producer 消费者：consumer       |
|    topic     | 可选 |            默认值：kafka_test_topic            |
|    input     | 可选 |           绝对路径：/root/input.txt            |
|    output    | 可选 |           绝对路径：/root/output.txt           |
|      ip      | 必须 |              服务地址：10.0.3.24               |
| service_port | 必须 |                服务端口：18108                 |
|     mode     | 可选 |        earliest / latest(默认值) / none        |


- mode参数说明

```bash
earliest： 当各分区下有已提交的offset时，从提交的offset开始消费；无提交的offset时，从头开始消费
latest： 当各分区下有已提交的offset时，从提交的offset开始消费；无提交的offset时，消费新产生的该分区下的数据
none： topic各分区都存在已提交的offset时，从offset后开始消费；只要有一个分区不存在已提交的offset，则抛出异常
```

- input参数说明

```bash
当role为producer时必传，其他可不传
```

- output参数说明

```bash
当role为consumer时必传，其他可不传
```



## 3. 输出

```
[root@oracle light]# ls

input.txt output.txt

```



## 4.执行方式

```bash
# 1 只指定生产者，仅仅生产数据
python3 kafka_tool.py --ip 10.0.14.157 --service_port 9092 --role producer --input input.txt

# 2 只指定消费者，仅仅消费数据
python3 kafka_tool.py --ip 10.0.14.157 --service_port 9092 --role consumer --output output.txt

# 3 什么都不指定：自测，生产者生产数据，消费者消费数据
python3 test.py --ip 10.0.14.157 --service_port 9092
```
