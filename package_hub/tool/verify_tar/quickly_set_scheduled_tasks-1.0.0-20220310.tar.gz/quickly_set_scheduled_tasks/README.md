
## 快速设置计划任务工具

### 场景描述
将crontab配置格式可视化，通过脚本转换crontab任务格式，同步到计划任务（crontab）中
将分、时、日、月、周，通过页面配置显示

### 1.依赖：

- Python环境：Python 3.6
- 三方库：  python-crontab

```bash
pip3 install python-crontab
``` 

###  2.入参

| 字段     | 要求 | 字段说明         |
| -------- | ---- | --------- |
| m      |   可选 | 分钟 |
| H      |   可选 | 小时 |
| d      |   可选 | 天 |
| M      |   可选 | 月 |
| w      |   可选 | 周 |
| command      |   可选 | 执行命令 |


### 3. 输出

```bash
[root@localhost ~]# python3 test.py -m 5 -command 'echo 123 >> test.txt'
[root@localhost ~]# 
[root@localhost ~]# crontab -l
5 * * * * echo 123 >> test.txt
```

### 4.执行方式

```bash
# 示例 ： 每5分钟执行一次，参数传递时，一个横杠
python3 test.py -m 5 -command 'echo 123 >> test.txt'
```
