#!/usr/bin/env python3
# -*- coding:utf8 -*-
# Author: light.wang
# Create Date: 2021-11-18 17:02:00
# Last Modified: 2021-11-18 17:02:00
# Description: 在多台主机上批量执行ping命令快速检查，主机到主机，主机到域名之间网络是否连通
import json
import argparse
import subprocess
from crontab import CronTab


class CrontabTask:

    @classmethod
    def parameters(cls):
        """
        传递参数
        :return:
        """
        parser = argparse.ArgumentParser()
        parser.add_argument("--ip", "-ip", help="当前主机IP")
        parser.add_argument("--minute", "-m", help="分")
        parser.add_argument("--hour", "-H", help="时")
        parser.add_argument("--day", "-d", help="日")
        parser.add_argument("--month", "-M", help="月")
        parser.add_argument("--week", "-w", help="周")
        parser.add_argument("--command", "-command", help="命令", required=True)
        _crontab = parser.parse_args()
        return _crontab

    @staticmethod
    def system_command(command):
        """
        调用linux系统命令
        :param command:
        :return:
        """
        shell = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        stdout, stderr = shell.communicate()
        try:
            return stdout.decode("utf8"), stderr.decode("utf8"), shell.returncode
        except Exception:
            return stdout.decode("gbk"), stderr.decode("gbk"), shell.returncode

    def add_task(self):
        cron = CronTab(user='root')
        job = cron.new(command=self.parameters().command, comment='')
        if self.parameters().minute:
            job.minute.on(self.parameters().minute)
        if self.parameters().hour:
            job.hour.on(self.parameters().hour)
        if self.parameters().day:
            job.day.on(self.parameters().day)
        if self.parameters().month:
            job.month.on(self.parameters().month)
        if self.parameters().week:
            job.dow.on(self.parameters().week)
        cron.write()


if __name__ == '__main__':
    p = CrontabTask()
    p.add_task()
    #  pip3 install python-crontab
    