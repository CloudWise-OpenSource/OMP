
## Yum安装软件工具

### 场景描述
将yum工具操作可视化，可快速在多台主机上执行yum命令安装软件，内置常用故障定位命令软件包
- 自动配置yum源，进行安装工具命令时需要先配置本地Yum源，解压软件安装包，配置Yum。如果检查到Yum源已经配置完成，跳过配置Yum源直接安装软件包。

### 1.依赖：
- Python环境：Python 3.6
- 安装包地址： http://10.0.3.236/f/9e52ad931a0e4a78a72c/?dl=1

###  2.入参
| 字段    | 要求  | 说明                                                |
| -------| ----  | -------- |
| path   | 可选  | /root/packages |
| app    | 必选  | wget,vim   |
                               


### 3.可安装软件列表
```
wget 
ntpdate 
rsync 
tmpwatch 
tree 
telnet 
nc 
nmap 
iftop 
iotop  
unzip 
htop 
lrzsz 
sysstat
lsof 
telnet 
mdadm
```


### 4.执行方式
```bash
./python3 test.py --path /root/packages --app 'wget,rsync'
```