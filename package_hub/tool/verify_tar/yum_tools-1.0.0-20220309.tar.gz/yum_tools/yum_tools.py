#!/usr/bin/env python3
# -*- coding:utf8 -*-
# Author: light.wang
# Create Date: 2021-11-15 17:02:00
# Last Modified: 2021-11-15 17:02:00
# Description: 将yum工具操作可视化，可快速在多台主机上执行yum命令安装软件，内置常用故障定位命令软件包
import os
import argparse
import subprocess


class YumInstallTools:

    @classmethod
    def parameters(cls):
        """
        传递参数
        :return:
        """
        parser = argparse.ArgumentParser()
        parser.add_argument("--ip", "-ip", help="当前主机IP")
        parser.add_argument("-app", "--app", help="yum应用")
        parser.add_argument("-path", "--path", help="安装包位置")
        _yum_tools = parser.parse_args()
        return _yum_tools

    @staticmethod
    def system_command(command):
        """
        调用linux系统命令
        :param command:
        :return:
        """
        shell = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        stdout, stderr = shell.communicate()
        try:
            return stdout.decode("utf8"), stderr.decode("utf8"), shell.returncode
        except Exception:
            return stdout.decode("gbk"), stderr.decode("gbk"), shell.returncode

    def create_repo(self):
        """
        创建repo文件
        :return:
        """
        repo_file = """
        [base]
        baseurl=file://{}
        enabled=1
        gpgcheck=0
        name='yunzhihui'
        """.format(self.parameters().path)
        data = repo_file.replace(' ', '').strip()

        define_path = '/etc/yum.repos.d/yunzhihui.repo'
        with open(define_path, 'w') as f:
            f.write(data)

        self.system_command('yum clean all && yum makecache')

    def install(self):
        """
        安装yum源软件
        :return:
        """
        for app in self.parameters().app.split(','):
            stdout, stderr, return_code = self.system_command('yum install -y {}'.format(app))
            print(stdout)

    def run(self):

        stdout, stderr, return_code = self.system_command(
            "yum clean all && yum repolist|grep repolist|awk -F ':' '{print $2}'"
        )

        if str(stdout.strip()) == '0' and self.parameters().path:
            self.create_repo()

        self.install()


if __name__ == '__main__':
    yum = YumInstallTools()
    yum.run()
