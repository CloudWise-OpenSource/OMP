## 防火墙状态检查工具
### 场景描述
当发生连接timeout报错时，快速检查selinux状态是否开启和防火墙状态和规则是否正在运行。
- 当防火墙运行时输出防火墙状态和selinux状态，并且格式化输出当前防火墙规则。JSON数据
- 未运行输出防火墙未运行状态和selinux状态。JSON数据

### 1.依赖：
- Python环境：Python 3.6

###  2.入参
无入参

### 3.输出
参数说明

| 字段     |  参数说明        |
| -------- | -------------------------|
| Disabled |   表示selinux关闭 |
| Enforcing |   表示selinux开启 |
| ON   | 表示防火墙开启            |
| OFF  |  表示防火墙关闭         |

```json
{
	"selinux": {
		"selinux_status": "Disabled"
	},
	"iptables": {
		"iptables_status": "ON",
		"iptables_rule": [{
			"FORWARD": [{
				"target": "DOCKER-USER",
				"prot": "all",
				"in": "*",
				"out": "*",
				"source": "0.0.0.0/0",
				"destination": "0.0.0.0/0"
			}, {
				"target": "DOCKER-ISOLATION-STAGE-1",
				"prot": "all",
				"in": "*",
				"out": "*",
				"source": "0.0.0.0/0",
				"destination": "0.0.0.0/0"
			}, {
				"target": "ACCEPT",
				"prot": "all",
				"in": "*",
				"out": "docker0",
				"source": "0.0.0.0/0",
				"destination": "0.0.0.0/0"
			}, {
				"target": "DOCKER",
				"prot": "all",
				"in": "*",
				"out": "docker0",
				"source": "0.0.0.0/0",
				"destination": "0.0.0.0/0"
			}, {
				"target": "ACCEPT",
				"prot": "all",
				"in": "docker0",
				"out": "!docker0",
				"source": "0.0.0.0/0",
				"destination": "0.0.0.0/0"
			}, {
				"target": "ACCEPT",
				"prot": "all",
				"in": "docker0",
				"out": "docker0",
				"source": "0.0.0.0/0",
				"destination": "0.0.0.0/0"
			}]
		}]
	},
	"firewall": {
		"firewall_status": "OFF",
		"firewall_rules": []
	}
}
```

### 4.执行方式
```bash
./python3 firewall_status_check.py
````

