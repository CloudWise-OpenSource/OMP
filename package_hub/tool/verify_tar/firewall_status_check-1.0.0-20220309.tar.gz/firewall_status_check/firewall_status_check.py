#!/usr/bin/env python3
# -*- coding:utf8 -*-
# Author: light.wang
# Create Date: 2021-11-15 17:02:00
# Last Modified: 2021-11-15 17:02:00
# Description: 当发生连接timeout报错时，快速检查selinux状态是否开启和防火墙状态和规则是否正在运行。
import re
import json
import subprocess


class FirewallStatusCheck:

    @staticmethod
    def system_command(command):
        """
        调用linux系统命令
        :param command:
        :return:
        """
        shell = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        stdout, stderr = shell.communicate()
        try:
            return stdout.decode("utf8"), stderr.decode("utf8"), shell.returncode
        except Exception as e:
            return stdout.decode("gbk"), stderr.decode("gbk"), shell.returncode

    def check_selinux_status(self):
        """
        检查selinux状态
        :return:
        """
        stdout, stderr, return_code = self.system_command('getenforce')
        return {'selinux_status': stdout.strip()}

    def check_iptables_status(self):
        """
        检查iptables状态
        :return:
        """
        stdout, stderr, return_code = self.system_command('cat /etc/redhat-release')
        # centos_version = re.search('release.*?(\d+)',stdout).group(1)
        centos_version = re.findall('(\d+)',stdout)[0]
        stdout1, stderr1,iptables_status_code = self.system_command('iptables -nvL')
        if (str(centos_version).startswith('7')) and iptables_status_code != 0:
            return {'iptables_status': 'OFF','iptables_rule': []}
        else:
            stdout, stderr, return_code = self.system_command('service iptables status')
            if '未运行防火墙' in stdout:
                iptables_status = 'OFF'
                return json.dumps({'iptables_status': iptables_status,'iptables_rule': []})
            else:
                iptables_status = 'ON'
                iptables_stdout, stderr, return_code = self.system_command('iptables -nvL')
                iptables_chain_list = []

                for iptables_rule in iptables_stdout.strip().split('Chain'):
                    if iptables_rule:
                        chain_name = iptables_rule.strip().split('\n')[0].split(' ')[0]
                        if iptables_rule.strip().split('\n')[2:]:
                            chain_value = []
                            params = re.split(r' +', iptables_rule.strip().split('\n')[1].strip())
                            rule_list = iptables_rule.strip().split('\n')[2:]
                            for rule in rule_list:
                                rule_value = re.split(r' +', rule.strip())
                                if {
                                    params[2]: rule_value[2],
                                    params[3]: rule_value[3],
                                    params[5]: rule_value[5],
                                    params[6]: rule_value[6],
                                    params[7]: rule_value[7],
                                    params[8]: rule_value[8],
                                } not in chain_value:

                                    chain_value.append(
                                        {
                                            params[2]: rule_value[2],
                                            params[3]: rule_value[3],
                                            params[5]: rule_value[5],
                                            params[6]: rule_value[6],
                                            params[7]: rule_value[7],
                                            params[8]: rule_value[8],
                                        }
                                )
                            iptables_chain_list.append({chain_name: chain_value})

                return {'iptables_status': iptables_status, 'iptables_rule':iptables_chain_list}

    def check_firewall_status(self):
        stdout, stderr, return_code = self.system_command('firewall-cmd --state')

        if stdout.strip() == 'running':
            firewall_status = 'ON'
            services_stdout, stderr, return_code = self.system_command('firewall-cmd --zone=public --list-services')
            services = services_stdout.strip().split(' ')
            ports_stdout, stderr, return_code = self.system_command('firewall-cmd --zone=public --list-ports')
            ports = ports_stdout.strip().split(' ')
            firewall_rules = {'services': services, 'ports': ports}
            return {'firewall_status': firewall_status, 'firewall_rules': firewall_rules}
        else:
            firewall_status = 'OFF'
            return {'firewall_status': firewall_status, 'firewall_rules': []}

    def check_status(self):

        selinux = self.check_selinux_status()
        iptables = self.check_iptables_status()
        firewall = self.check_firewall_status()

        print(json.dumps({'selinux': selinux, 'iptables': iptables, 'firewall': firewall}))
        return json.dumps({'selinux': selinux, 'iptables': iptables, 'firewall': firewall})


if __name__ == '__main__':
    firewall = FirewallStatusCheck()
    firewall.check_status()